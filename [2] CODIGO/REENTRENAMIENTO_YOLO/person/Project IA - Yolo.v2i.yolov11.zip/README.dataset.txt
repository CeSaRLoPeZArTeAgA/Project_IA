# Project IA - Yolo > 2026-06-28 8:11am
https://universe.roboflow.com/clauni/project-ia-yolo

Provided by a Roboflow user
License: CC BY 4.0

